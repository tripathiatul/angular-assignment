import { Component } from '@angular/core';

@Component({
  selector: 'app-prsr',
  templateUrl: './prsr.component.html',
  styleUrls: ['./prsr.component.scss']
})
export class PrsrComponent {

}
