export class MessageServices{
    messageAlert(){
        alert("button clicked")
    }
}