import { Component, EventEmitter, Input, Output } from '@angular/core';
import { DesignutilityService } from 'src/app/appServices/designutility.service';
import { MessageServices } from '../../appServices/message.service';

@Component({
  selector: 'app-componentcommunication',
  templateUrl: './componentcommunication.component.html',
  styleUrls: ['./componentcommunication.component.css']
})
export class ComponentcommunicationComponent {
// selectedProduct:string=""
//   productselected:boolean=false;
//   yourName:string="atul"
//   Prodcart:string=""
// isbuttonclicked:boolean=false;
 @Input() studentDetail:any[]=[];

// childarray:any[]=[{name:"Abc",
// age:25},
// {
//   name:"mno",
//   age:23
// } 


// ];



products: any[] = [];

 constructor( 
  private _messageservice: DesignutilityService
){};

ngOnInit()
{
  // this.product=this._messageservice.products;
  // console.log({copy: this._messageservice.products});
  
  this._messageservice.products()
  .subscribe((products) => this.products = products)

}


buttonClick(){
const msgservice=new MessageServices();
msgservice.messageAlert()
}



  Addedcart(product:any){
    // this.productselected=true;
      // this.selectedProduct=product;
  }
  // goTocart(productselected: any)
  // {

  //   this.Prodcart=productselected;
  // }
//   Onclickbtn()
//   {
// const msgservice=new MessageServices();
// msgservice.messageAlert()
//   }
}
