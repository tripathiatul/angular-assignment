import { Component, EventEmitter, Input, Output } from '@angular/core';

@Component({
  selector: 'app-parenttochild',
  templateUrl: './parenttochild.component.html',
  styleUrls: ['./parenttochild.component.scss']
})
export class ParenttochildComponent {
@Input() item:string ="";


@Input() name:any={

};


tobsent={
  name:"Atul",
  age:23
}


@Output() getValue= new EventEmitter<any>()

// ngOnInit(){
//   this.getValueEmit()
  
  
// }
// getValueEmit()
// {
//   this.getValue.emit(this.tobsent);
// }

//child to parent
@Output() updateData=new EventEmitter<any>()
}
