import { Component } from "@angular/core";

@Component({
selector : 'app-myContainer',
templateUrl:'./myContainer.component.html',
styleUrls: ['./myContainer.component.css']
})

export class MyContainerComponent
{

}