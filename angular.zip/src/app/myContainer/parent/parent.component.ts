import { Component } from '@angular/core';

@Component({
  selector: 'app-parent',
  templateUrl: './parent.component.html',
  styleUrls: ['./parent.component.scss']
})
export class ParentComponent {
data:string="mnop";
item1=""
item2=""
valName={
  name:"atul",
  age:"23"
}
ValuetoAccess(item:any)
{
  this.item1=item.name
  this.item2=item.age
console.log(item.name,item.age);

}


DataTofetch(item:any)
{
console.log(item);

}
}
