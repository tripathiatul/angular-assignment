import { Component } from '@angular/core';

@Component({
  selector: 'app-eventbinding',
  templateUrl: './eventbinding.component.html',
  styleUrls: ['./eventbinding.component.scss']
})
export class EventbindingComponent {

// message:string=""
//   onAddcart(event :any){
//   this.message=event.target.value+"    " +"added in cart";
//   }

// onInputClick(event:any){
// console.log(event);
// console.log(event.target.value)
//   }
getInputInfo(inputInfo :any,inputInfo1:any)
{
  console.log(inputInfo.name ,inputInfo1.name)
}

}

