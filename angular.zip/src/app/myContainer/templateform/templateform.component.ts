import { Component } from '@angular/core';

@Component({
  selector: 'app-templateform',
  templateUrl: './templateform.component.html',
  styleUrls: ['./templateform.component.scss']
})
export class TemplateformComponent {

  title="Enter the details"


  constructor(){}
  userlogin(item:any)
  {
    console.warn(item);
    
  }
}
