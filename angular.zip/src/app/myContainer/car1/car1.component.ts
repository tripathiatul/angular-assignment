import { Component } from '@angular/core';
import { DesignutilityService } from 'src/app/appServices/designutility.service';

@Component({
  selector: 'app-car1',
  templateUrl: './car1.component.html',
  styleUrls: ['./car1.component.scss']
})
export class Car1Component {

  userName:string="Atul"
Updatename(item:any){
  // this.userName=item.value
  this.msg.username.next(item.value)
}
constructor(private msg:DesignutilityService){
  this.msg.username.subscribe(uname=>{this.userName=uname})
}
}
