import { Component, EventEmitter, Input, Output } from '@angular/core';

@Component({
  selector: 'app-childcontent',
  templateUrl: './childcontent.component.html',
  styleUrls: ['./childcontent.component.scss']
})
export class ChildcontentComponent {

  @Input() selectedProduct:string=""
 @Input() productselected:boolean=false;
  Addedcart(product:any){
    this.productselected=true;
      this.selectedProduct=product;
}
  goTocart(productselected: any)
  {

    // this.Prodcart=productselected;
  }
}
