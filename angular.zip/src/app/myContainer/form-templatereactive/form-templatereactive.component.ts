import { Component } from '@angular/core';

@Component({
  selector: 'app-form-templatereactive',
  templateUrl: './form-templatereactive.component.html',
  styleUrls: ['./form-templatereactive.component.scss']
})
export class FormTemplatereactiveComponent {
username:any='Atul';
Clickedbutton(username:any){
  console.log(username.value)
}

}
