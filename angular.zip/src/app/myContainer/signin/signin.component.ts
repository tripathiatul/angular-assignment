import { Component } from '@angular/core';
import { EmailValidator, FormControl, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
@Component({
  selector: 'app-signin',
  templateUrl: './signin.component.html',
  styleUrls: ['./signin.component.scss']
})
export class SigninComponent {

constructor(private router : Router){

}


  loginForm = new FormGroup({
    user: new FormControl('', [Validators.required, Validators.email,Validators.minLength(2)]),
    password: new FormControl('', [Validators.required, Validators.minLength(8)])
  })
  LoginUser() {
   
   
    console.log(this.loginForm.valid);
    if(this.loginForm.valid && this.loginForm.value.user !== ""){
      this.router.navigateByUrl("/cardassignment")
    }
else{
  console.log("invalid")
}
  }

}
