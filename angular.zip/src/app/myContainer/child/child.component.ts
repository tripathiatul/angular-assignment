import { Component, SimpleChange, SimpleChanges } from '@angular/core';
import { Input ,OnInit,AfterViewInit , OnChanges,DoCheck ,AfterContentInit,
AfterContentChecked} from "@angular/core";
@Component({
  selector: 'app-child',
  templateUrl: './child.component.html',
  styleUrls: ['./child.component.scss']
})
export class ChildComponent  {

  // @Input() myValue="uxtrend";
  constructor(){
    console.log("constructor called");
    
  }
  ngOnChanges(changes:SimpleChanges){
    console.log("onchanges called " );
    
  }
  ngDoCheck(){
    console.log("docheck challed");
    
  }
  ngOninit()
  {
    console.log("ngoninit called");
    
  }
ngAfterContentInit(){
  console.log("ng Content Init called");
   
}
ngAfterContentCheck()
{

}
ngAfterViewInit()
{
  console.log("AfterViewInit called");  
}
ngAfterViewChecked(){
  console.log("ngafterviewchecked called");
  
}
ngOnDestroy()
{
  console.log("destroyed");
  
}
}

