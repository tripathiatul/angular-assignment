import { Component } from '@angular/core';
import { DesignutilityService } from 'src/app/appServices/designutility.service';
import { DEFAULT_IMAGE_SIZE } from './cardConstants';

@Component({
  selector: 'app-cardassignment',
  templateUrl: './cardassignment.component.html',
  styleUrls: ['./cardassignment.component.css']
})
export class CardassignmentComponent {
  DefaultSize:string = DEFAULT_IMAGE_SIZE;
  constructor(private design:DesignutilityService){


  }

prod=[ {
  title:"",
  price:"",
  description:"",
  image:""
}];
ngOnInit(){
  this.design.cardproduct().subscribe(proddata=>{this.prod=proddata
  console.log(this.prod);
  })
  
}
}
