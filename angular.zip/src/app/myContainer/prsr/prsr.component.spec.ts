import { ComponentFixture, TestBed } from '@angular/core/testing';

import { PrsrComponent } from './prsr.component';

describe('PrsrComponent', () => {
  let component: PrsrComponent;
  let fixture: ComponentFixture<PrsrComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ PrsrComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(PrsrComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
