import { Component } from '@angular/core';
import { DesignutilityService } from 'src/app/appServices/designutility.service';

@Component({
  selector: 'app-subject',
  templateUrl: './subject.component.html',
  styleUrls: ['./subject.component.scss']
})
export class SubjectComponent {
  userName:string="Atul"
  Updatename(item:any){
    this.userName=item.value
  }
  constructor(private msg:DesignutilityService){
    this.msg.username.subscribe(uname=>{this.userName=uname})
  }}
