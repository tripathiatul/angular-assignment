import { ComponentFixture, TestBed } from '@angular/core/testing';

import { FormTemplatereactiveComponent } from './form-templatereactive.component';

describe('FormTemplatereactiveComponent', () => {
  let component: FormTemplatereactiveComponent;
  let fixture: ComponentFixture<FormTemplatereactiveComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ FormTemplatereactiveComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(FormTemplatereactiveComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
