import { Component } from '@angular/core';

@Component({
  selector: 'app-interpolation',
  templateUrl: './interpolation.component.html',
  styleUrls: ['./interpolation.component.scss']
})
export class InterpolationComponent {
 myName:string='Atul Tripathi'
onBoard=()=>{
  return "Welcome"+ " " +this.myName;
}
}
