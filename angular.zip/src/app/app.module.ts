import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { FormsModule } from "@angular/forms";
import { HttpClientModule} from "@angular/common/http"
import { AppComponent } from './app.component';
import { MyContainerComponent } from './myContainer/myContainer.components';
import { TopnavComponent } from './myContainer/topnav/topnav.component';
import { HeaderComponent } from './myContainer/header/header.component';
import { Textsec1Component } from './myContainer/textsec1/textsec1.component';
import { Textsec2Component } from './myContainer/textsec2/textsec2.component';
// ngx
import { ButtonsModule } from 'ngx-bootstrap/buttons';

import { InterpolationComponent } from './myContainer/interpolation/interpolation.component';
import { ClassbindingComponent } from './myContainer/classbinding/classbinding.component';
import { EventbindingComponent } from './myContainer/eventbinding/eventbinding.component';
import { TwowaybindingComponent } from './myContainer/twowaybinding/twowaybinding.component';
import { ComponentcommunicationComponent } from './myContainer/componentcommunication/componentcommunication.component';
import { ChildcontentComponent } from './myContainer/childcontent/childcontent.component';
import { MessageServices } from './appServices/message.service';
import { DesignutilityService } from './appServices/designutility.service';
import { HomecomponentComponent } from './myContainer/homecomponent/homecomponent.component';
import { AboutComponent } from './myContainer/about/about.component';
// import { ChildComponent } from './myContainer/child/child.component';
import { CardassignmentComponent } from './myContainer/cardassignment/cardassignment.component';
import { ParentComponent } from './myContainer/parent/parent.component';
import { ParenttochildComponent } from './myContainer/parenttochild/parenttochild.component';
import { PrsrComponent } from './myContainer/prsr/prsr.component';
import { TemplateformComponent } from './myContainer/templateform/templateform.component';
import { ReactiveFormComponent } from './myContainer/reactive-form/reactive-form.component';
import {  ReactiveFormsModule} from "@angular/forms";
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
// import { SrpractComponent } from './myContainer/srpract/srpract.component';
import {MatButtonModule} from '@angular/material/button';
import { SigninComponent } from './myContainer/signin/signin.component';
import { SubjectComponent } from './myContainer/subject/subject.component';
import { Routes ,RouterModule } from '@angular/router';
import { Car1Component } from './myContainer/car1/car1.component';
import { Car2Component } from './myContainer/car2/car2.component';
import { Car3Component } from './myContainer/car3/car3.component';
import { FormTemplatereactiveComponent } from './myContainer/form-templatereactive/form-templatereactive.component';

const appRouter:Routes=[
 {path:"cardassignment",component:CardassignmentComponent},
 {path:"",component:SigninComponent, pathMatch:"full"}
]

@NgModule({
  declarations: [
    AppComponent, MyContainerComponent, TopnavComponent, HeaderComponent, Textsec1Component, Textsec2Component, InterpolationComponent, ClassbindingComponent, EventbindingComponent, TwowaybindingComponent, ComponentcommunicationComponent, ChildcontentComponent, HomecomponentComponent, AboutComponent, CardassignmentComponent, ParentComponent, ParenttochildComponent, PrsrComponent, TemplateformComponent, ReactiveFormComponent, SigninComponent, SubjectComponent, Car1Component, Car2Component, Car3Component, FormTemplatereactiveComponent,
  ],
  imports: [
    BrowserModule,
    FormsModule,
    HttpClientModule,
    ReactiveFormsModule,
    BrowserAnimationsModule,
    MatButtonModule,
    ButtonsModule.forRoot(),
RouterModule.forRoot(appRouter),
  ],
  providers: [DesignutilityService,
  MessageServices]
  ,
  bootstrap: [AppComponent]
})
export class AppModule { }
