import { Injectable } from '@angular/core';
import { HttpClient } from "@angular/common/http";
import { BehaviorSubject, Observable, Subject } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class DesignutilityService {
  constructor(private http: HttpClient) { }
  messageAlert(): void {
    alert("button clicked")
  }
  cardproduct(): Observable<any> {
    return this.http.get('https://fakestoreapi.com/products')
  }
  designUtil() {
    alert("called from design");
  }
  // products=[{
  //   name:"laptop",id:"001"
  // },
  // {
  //   name:"laptop",id:"002"
  // },
  // {
  //   name:"laptop",id:"003"
  // }
  // ];
  products(): Observable<any> {
    return this.http.get('https://jsonplaceholder.typicode.com/users')
  }



// username= new Subject<any>();
username=new BehaviorSubject('atul')
}
