import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CardassignmentComponent } from './cardassignment.component';

describe('CardassignmentComponent', () => {
  let component: CardassignmentComponent;
  let fixture: ComponentFixture<CardassignmentComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ CardassignmentComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(CardassignmentComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
