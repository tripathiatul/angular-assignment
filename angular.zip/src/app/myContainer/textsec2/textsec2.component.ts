import { Component } from '@angular/core';

@Component({
  selector: 'app-textsec2',
  templateUrl: './textsec2.component.html',
  styleUrls: ['./textsec2.component.css']
})
export class Textsec2Component {

}
